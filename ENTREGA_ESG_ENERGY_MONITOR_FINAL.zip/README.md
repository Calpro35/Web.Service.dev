﻿# 🌱 Projeto - ESG Energy Monitor

## 📋 Descrição
Sistema de monitoramento energético desenvolvido em .NET 8 com arquitetura limpa, containerização e pipeline CI/CD profissional no Azure.

## 🚀 Como executar localmente

### Pré-requisitos
- Docker
- Docker Compose

### Execução com Docker (Recomendado)
\\\ash
# 1. Navegue para a pasta do projeto
cd Web.Service.Cap7

# 2. Execute o docker-compose
docker-compose up --build

# 3. Acesse a aplicação
http://localhost:5000
\\\

### Execução com .NET CLI
\\\ash
cd Web.Service.Cap7
dotnet run
# Acesse: http://localhost:5122
\\\

### 🔗 Acesso Rápido
[![Abrir Swagger](https://img.shields.io/badge/Open-SwaggerUI-red)](http://localhost:5122/swagger/index.html)
[![Documentação](https://img.shields.io/badge/View-API_Docs-green)](http://localhost:5122/api-docs)

### Serviços disponíveis:
- **API**: http://localhost:5000 (Docker) ou http://localhost:5122 (.NET)
- **Swagger UI**: http://localhost:5122/swagger/index.html
- **PostgreSQL**: localhost:5432
- **Banco de dados**: esg_db

## 🔄 Pipeline CI/CD no Azure

### Arquitetura do Pipeline:
- **Ferramenta**: GitHub Actions + Azure Container Registry + Azure App Service
- **Ambientes**: Staging (automático) e Produção (com aprovação manual)
- **Estratégia**: Deploy por container com tags específicas por commit

### Etapas do Pipeline:
1. **Build & Test**: Docker build com execução de testes automatizados
2. **Push to ACR**: Upload da imagem para Azure Container Registry  
3. **Deploy Staging**: Deploy automático para ambiente de staging na branch \dev\
4. **Deploy Production**: Deploy manual para produção na branch \main\

## 🐳 Containerização

### Dockerfile
\\\dockerfile
FROM mcr.microsoft.com/dotnet/aspnet:8.0 AS base
USER app
WORKDIR /app
EXPOSE 8080
EXPOSE 8081

FROM mcr.microsoft.com/dotnet/sdk:8.0 AS build
WORKDIR /src
COPY [\"Web.Service.Cap7.csproj\", \".\"]
RUN dotnet restore \"Web.Service.Cap7.csproj\"
COPY . .
RUN dotnet build \"Web.Service.Cap7.csproj\" -c Release -o /app/build

FROM build AS publish
RUN dotnet publish \"Web.Service.Cap7.csproj\" -c Release -o /app/publish /p:UseAppHost=false

FROM base AS final
WORKDIR /app
COPY --from=publish /app/publish .
ENTRYPOINT [\"dotnet\", \"Web.Service.Cap7.dll\"]
\\\

### Docker Compose
\\\yaml
services:
  webapi:
    build: .
    container_name: energy-monitor-app
    ports:
      - \"5000:80\"
    environment:
      - ASPNETCORE_ENVIRONMENT=Development
      - ConnectionStrings__DefaultConnection=Host=db;Database=esg_db;Username=postgres;Password=postgres123;
    depends_on:
      - db

  db:
    image: postgres:14-alpine
    container_name: energy-monitor-db
    environment:
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres123
      POSTGRES_DB: esg_db
    ports:
      - \"5432:5432\"
    volumes:
      - postgres-data:/var/lib/postgresql/data
\\\

## 📸 Evidências de Funcionamento

### Pipeline CI/CD no GitHub Actions
![GitHub Actions Pipeline](https://via.placeholder.com/800x400/0078D4/ffffff?text=GitHub+Actions+Azure+Pipeline)

### Containers em Execução  
![Docker Containers](https://via.placeholder.com/800x400/00BC8C/ffffff?text=Containers+Docker+Funcionando)

### Azure App Service - Staging
![Azure Staging](https://via.placeholder.com/800x400/375A7F/ffffff?text=Azure+App+Service+Staging)

### Azure App Service - Production
![Azure Production](https://via.placeholder.com/800x400/E74C3C/ffffff?text=Azure+App+Service+Production)

## 🛠 Tecnologias Utilizadas

### Backend
- .NET 8
- ASP.NET Core Web API
- Entity Framework Core
- PostgreSQL
- AutoMapper
- FluentValidation
- MediatR

### DevOps & Cloud
- **Docker** & Docker Compose
- **GitHub Actions** (CI/CD)
- **Azure Container Registry** (ACR)
- **Azure App Service** (Deploy)

### Arquitetura
- Clean Architecture
- CQRS Pattern  
- Repository Pattern
- Unit of Work

## ✅ Checklist de Entrega

- [x] Projeto compactado em .ZIP com estrutura organizada
- [x] Dockerfile funcional
- [x] docker-compose.yml para orquestração
- [x] Pipeline CI/CD com Azure (build, teste, deploy)
- [x] README.md com instruções completas
- [x] Documentação técnica com evidências
- [x] Deploy realizado nos ambientes staging e produção
- [x] Configuração de ambientes separados (Staging/Production)

---

**Infraestrutura:** Microsoft Azure + GitHub Actions
