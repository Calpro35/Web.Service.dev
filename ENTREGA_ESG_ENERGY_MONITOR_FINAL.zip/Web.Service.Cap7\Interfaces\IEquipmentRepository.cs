﻿using Web.Service.Cap7.Models;

namespace Web.Service.Cap7.Interfaces;

public interface IEquipmentRepository : IRepository<Equipment>
{

}
