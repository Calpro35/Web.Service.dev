﻿namespace Web.Service.Cap7.Models.Enums;

public enum UserRoles
{
    Admin = 1,
    User
}
