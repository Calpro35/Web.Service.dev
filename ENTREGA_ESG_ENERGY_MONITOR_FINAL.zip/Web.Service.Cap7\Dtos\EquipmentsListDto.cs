﻿namespace Web.Service.Cap7.Dtos;

public sealed record EquipmentsListDto(
    int Id,
    string Name,
    bool IsActive
);
